from flask import Flask, jsonify
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///product_db.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    price = db.Column(db.Float, nullable=False)
    image_url = db.Column(db.String(255))

def insert_dummy_products():
    dummy_products = [
        {
            'name': 'Pearl Sweatshirt',
            'description': 'Dinner-vibe',
            'price': 19.99,
            'image_url': 'https://static.zara.net/assets/public/c469/88db/acc74a40936b/4027d721393b/05070627800-e1/05070627800-e1.jpg?ts=1706548781219&w=850'
        },
        {
            'name': 'Blue- Ev-erla-st',
            'description': 'For the NYC Winter',
            'price': 29.99,
            'image_url': 'https://static.zara.net/assets/public/b9e2/c7e5/15c2416cbca3/b456df210d66/00264317401-e1/00264317401-e1.jpg?ts=1707218987328&w=850'
        },
        {
            'name': 'Everlast sweatshirt',
            'description': 'Colors of the Winter',
            'price': 13.99,
            'image_url': 'https://static.zara.net/assets/public/9ba0/d0ed/448947448e96/1d031bc621d6/00264319807-e1/00264319807-e1.jpg?ts=1707218983870&w=850'
        },
        {
            'name': 'Multicolored Sweatshirt',
            'description': 'Retro-Hip/Hop style',
            'price': 19.99,
            'image_url': 'https://static.zara.net/assets/public/ab49/b7ee/1d0e46edaf1f/02031861d823/00264325802-e1/00264325802-e1.jpg?ts=1707218983825&w=850'
        },
        {
            'name': 'Beverly Hills Sweatshirt',
            'description': 'New Style',
            'price': 17.99,
            'image_url': 'https://static.zara.net/assets/public/b8be/2b9c/9b364727b16a/5d2a8eb5531b/06050316712-e1/06050316712-e1.jpg?ts=1711454618101&w=850'
        }
    ]

    for product_data in dummy_products:
        product = Product(**product_data)
        db.session.add(product)

    db.session.commit()

@app.route('/products', methods=['GET'])
def get_all_products():
    products = Product.query.all()
    return jsonify([{'id':p.id,'name': p.name, 'description': p.description, 'price': p.price, 'image_url': p.image_url} for p in products])


if __name__ == '__main__':
    with app.app_context():
        
        db.create_all()
        insert_dummy_products()
    app.run(host="0.0.0.0", debug=True,  port=5002)
